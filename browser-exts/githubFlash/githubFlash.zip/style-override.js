
let __style = document.createElement("style");
__style.textContent = ".flash.flash-warn { display: none; }";
document.body.appendChild(__style);

